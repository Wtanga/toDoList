<?php


namespace App\MVC\Models;


use Framework\MysqlModel;

class UserModel extends MysqlModel
{
    protected $table = "user";


}
