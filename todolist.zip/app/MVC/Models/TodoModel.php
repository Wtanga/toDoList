<?php


namespace App\MVC\Models;


use Framework\MysqlModel;

class TodoModel extends MysqlModel
{
    protected $table = "tasks";


}
